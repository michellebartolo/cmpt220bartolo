/**
  * file: DBConnect.java
  * author: Michelle Bartolo
  * course: CMPT 220
  * assignment: Project 2
  * due date: May 4, 2017
  * version: 1.3
  * 
  * This file contains the code that allows records from Bartolo Medical Sales Inc database to be outputted
  */
package database_console;

import java.sql.Statement; //To execute a SQL statement on the table, need to set up a Statement object
import java.sql.Connection; //To connect to a database I needed to import a Connection object
import java.sql.DriverManager; //Driver maager passes in database username, password, and location of the database.
import java.sql.ResultSet; //executeQuery method returns all the records in a ResultSet, so this needs to be imported
import java.sql.SQLException;

public class DBConnect {
  public static void main(String[] args) {
    /*DriverManager attempts to connect to the database, if it fails then 
      a SQLException error occurs. This try … catch statement traps the error
      in catch part */
    try{
      /*
       * jdbc:derby://localhost" is the database type and server being used,"1527" is the port number
       * The database is Bartolo Medical Sales Inc
       */
      String host = "jdbc:derby://localhost:1527/Bartolo Medical Sales Inc"; //database location (host address)
      String uName = "michelle"; //username of the database
      String uPass = "bartolo"; //password of the database
      Connection con = DriverManager.getConnection(host, uName, uPass); //sets up a connection to the database
     
      //Create a Statement object called stmt. The Statement object needs a Connection object, with the createStatment method
      Statement stmt = con.createStatement();
      String sql = "SELECT * FROM Manufacturer_Information"; //sql command to select all records from table
        
      /*Pass SQL query to a method of the Statement object called executeQuery. 
        The Statement object will then gather all the records that match the query.*/
      ResultSet rs = stmt.executeQuery(sql); //Result set rs will hold all records in the database
      
      //while loop with rs.next() to move through all the rows and display all the records
      while (rs.next()) {
        int id_col = rs.getInt("ID"); //set up the ID column to hold Integer values with getInt method
        String company_name = rs.getString("Company_Name"); //set up "Company_Name" column to hold strings with getString
        String contact_name = rs.getString("Contact_Name"); //set up "Contact_Name" column to hold strings with getString
        String phone_number = rs.getString("Phone_Number"); //set up "Phone_Number" column to hold strings with getString
        String email = rs.getString("Email"); //set up "Email" column to hold strings with getString
        String address = rs.getString("Address"); //set up "Address" column to hold strings with getString
      
        //print line to display the record in the Output window, each column separated with a space and divider |
        String p = id_col + " | " + company_name + " | " + contact_name + " | " + phone_number + " | " + email + " | " + address;
        System.out.println(p);
      }
    }      
    //catch statement to trap and get message of SQLException error that may occur
    catch(SQLException err) {
      System.out.println(err.getMessage());
    }
  }
}
